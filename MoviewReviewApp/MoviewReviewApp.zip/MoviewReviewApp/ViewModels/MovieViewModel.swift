//
//  MovieViewModel.swift
//  MoviewReviewApp
//
//  Created by 김규철 on 3/3/25.
//

import Foundation
