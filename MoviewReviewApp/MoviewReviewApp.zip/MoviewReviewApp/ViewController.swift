//
//  ViewController.swift
//  MoviewReviewApp
//
//  Created by 김규철 on 3/3/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

